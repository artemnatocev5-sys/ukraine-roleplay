package ua.roleplay.launcher;

import android.app.AlertDialog;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.*;

public class DownloadsActivity extends BaseActivity {
    static final String[][] CATS = {{"textures", "Текстури"}, {"models", "Моделі"}, {"cars", "Автомобілі"},
            {"items", "Предмети"}, {"characters", "Персонажі"}, {"addons", "Інші доповнення"}, {"maps", "Карти"}};
    JSONObject cfg = new JSONObject();
    final Map<String, Downloader.Task> tasks = new HashMap<>();
    final Map<String, TextView> statusViews = new HashMap<>();
    final Map<String, String> progress = new HashMap<>();
    final Set<String> failed = new HashSet<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setup("ЗАВАНТАЖЕННЯ");
        Remote.load(this, j -> { cfg = j; render(); });
    }

    String cat(JSONObject f) {
        String c = f.optString("category");
        for (String[] x : CATS) if (x[0].equals(c)) return c;
        return "addons";
    }

    void render() {
        content.removeAllViews();
        statusViews.clear();
        JSONArray files = cfg.optJSONArray("files");
        if (files == null || files.length() == 0) {
            content.addView(U.text(this, "Файлів поки немає. Адміністратор додає їх через launcher.json.", 16));
            return;
        }
        for (String[] c : CATS) {
            boolean head = false;
            for (int i = 0; i < files.length(); i++) {
                JSONObject f = files.optJSONObject(i);
                if (f == null || !c[0].equals(cat(f))) continue;
                if (!head) { content.addView(U.header(this, c[1])); head = true; }
                U.add(content, card(f), 8);
            }
        }
    }

    View card(final JSONObject f) {
        final String id = f.optString("id");
        LinearLayout row = new LinearLayout(this);
        row.setBackground(U.box(this, U.PANEL, U.BORDER, 10));
        int p = U.dp(this, 12);
        row.setPadding(p, p, p, p);
        ImageView img = new ImageView(this);
        img.setScaleType(ImageView.ScaleType.CENTER_CROP);
        img.setBackgroundColor(0xFF2A2F5A);
        U.loadImage(img, f.optString("image"));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(U.dp(this, 72), U.dp(this, 72));
        ip.rightMargin = p;
        row.addView(img, ip);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView name = U.text(this, f.optString("name"), 17);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(name);
        String meta = "v" + f.optString("version") + " · " + f.optString("size") + " · " + f.optString("date");
        TextView m = U.text(this, meta, 12);
        m.setTextColor(0xFF9AA0C0);
        col.addView(m);
        U.add(col, U.text(this, f.optString("desc"), 14), 4);
        final TextView status = U.text(this, "", 13);
        status.setTextColor(U.YELLOW);
        statusViews.put(id, status);
        U.add(col, status, 4);

        LinearLayout btns = new LinearLayout(this);
        btns.setGravity(Gravity.START);
        boolean inst = Mc.installedFile(this, f);
        if (tasks.containsKey(id)) {
            status.setText(progress.containsKey(id) ? progress.get(id) : "Підключення…");
            TextView c = U.btn(this, "Скасувати", 14);
            c.setOnClickListener(v -> { Downloader.Task t = tasks.get(id); if (t != null) t.cancel = true; });
            btns.addView(c);
        } else if (inst) {
            status.setText("Завантажено ✓");
            TextView imp = U.btn(this, "Імпорт у Minecraft", 14);
            imp.setOnClickListener(v -> doImport(f));
            TextView del = U.btn(this, "Видалити", 14);
            del.setOnClickListener(v -> {
                new File(Downloader.dir(this), Mc.fileName(f)).delete();
                Prefs.remove(this, "dl_" + id);
                render();
            });
            btns.addView(imp);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-2, -2);
            dp.leftMargin = U.dp(this, 8);
            btns.addView(del, dp);
        } else {
            TextView dl = U.btn(this, failed.contains(id) ? "Повторити" : "Завантажити", 14);
            dl.setOnClickListener(v -> start(f));
            btns.addView(dl);
        }
        U.add(col, btns, 8);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        return row;
    }

    void doImport(JSONObject f) {
        if (!Mc.installed(this)) { U.toast(this, "Спочатку встановіть Minecraft Bedrock"); Mc.store(this); return; }
        if (!Mc.compat(this, f)) {
            new AlertDialog.Builder(this).setTitle("Несумісна версія")
                    .setMessage("Для цього файлу потрібен Minecraft " + f.optString("min_mc") + " або новіший. У вас: " + Mc.version(this))
                    .setPositiveButton("OK", null).show();
            return;
        }
        File file = new File(Downloader.dir(this), Mc.fileName(f));
        Mc.importFile(this, file);
        Mc.importHelp(this);
    }

    void start(final JSONObject f) {
        final String id = f.optString("id");
        failed.remove(id);
        tasks.put(id, Downloader.start(this, f.optString("url"), Mc.fileName(f), f.optString("sha256"), new Downloader.L() {
            public void progress(long done, long total) {
                String s = total > 0 ? (done * 100 / total) + "%  (" + (done >> 10) + " / " + (total >> 10) + " КБ)" : (done >> 10) + " КБ";
                DownloadsActivity.this.progress.put(id, s);
                TextView t = statusViews.get(id);
                if (t != null) t.setText(s);
            }
            public void ok(File file) {
                tasks.remove(id);
                Prefs.set(DownloadsActivity.this, "dl_" + id, f.optString("version"));
                U.toast(DownloadsActivity.this, "Завантажено: " + f.optString("name"));
                if (!isFinishing()) render();
            }
            public void fail(String m) {
                tasks.remove(id);
                failed.add(id);
                U.toast(DownloadsActivity.this, f.optString("name") + ": " + m);
                if (!isFinishing()) render();
            }
        }));
        render();
    }
}
