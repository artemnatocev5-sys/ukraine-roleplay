package ua.roleplay.launcher;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;
import org.json.JSONObject;
import java.util.List;

public class ServersActivity extends BaseActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setup("СЕРВЕРИ");
        Remote.load(this, cfg -> {
            content.removeAllViews();
            List<JSONObject> list = Remote.servers(this, cfg);
            for (JSONObject s : list) content.addView(card(cfg, s), params());
            TextView dl = U.btn(this, "ЗАВАНТАЖЕННЯ", 16);
            dl.setOnClickListener(v -> startActivity(new Intent(this, DownloadsActivity.class)));
            TextView nw = U.btn(this, "НОВИНИ", 16);
            nw.setOnClickListener(v -> startActivity(new Intent(this, NewsActivity.class)));
            U.add(content, dl, 16);
            U.add(content, nw, 8);
        });
    }

    android.widget.LinearLayout.LayoutParams params() {
        android.widget.LinearLayout.LayoutParams p = new android.widget.LinearLayout.LayoutParams(-1, -2);
        p.topMargin = U.dp(this, 8);
        return p;
    }

    android.view.View card(JSONObject cfg, JSONObject s) {
        android.widget.LinearLayout c = U.card(this);
        TextView name = U.text(this, s.optString("name", "Сервер"), 20);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        final String host = s.optString("host");
        final int port = s.optInt("port", 19132);
        c.addView(name);
        U.add(c, U.text(this, "IP: " + host + "   Порт: " + port, 14), 4);
        final TextView status = U.text(this, "Статус: перевірка…", 14);
        U.add(c, status, 4);
        U.add(c, U.text(this, "Версія: " + s.optString("version", "—"), 14), 4);
        U.add(c, U.text(this, s.optString("description", ""), 14), 4);
        TextView go = U.btn(this, "Підключитися", 16);
        go.setOnClickListener(v -> Flow.play(this, cfg, s));
        U.add(c, go, 10);
        if (!host.isEmpty()) Remote.EX.execute(() -> {
            final Pinger.R r = Pinger.ping(host, port);
            Remote.H.post(() -> {
                if (isFinishing()) return;
                status.setText(r.online
                        ? "Статус: Online · гравців " + r.players + (r.max > 0 ? "/" + r.max : "")
                        + (r.version.isEmpty() ? "" : " · " + r.version)
                        : "Статус: Offline");
            });
        });
        return c;
    }
}
