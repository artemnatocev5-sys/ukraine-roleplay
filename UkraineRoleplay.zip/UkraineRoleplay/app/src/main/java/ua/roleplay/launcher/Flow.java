package ua.roleplay.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import org.json.JSONObject;
import java.util.List;

/** Кнопка PLAY: нікнейм → сервер → Minecraft → обов'язкові файли → запуск. */
public class Flow {
    public static void play(final Activity a, final JSONObject cfg, final JSONObject srv) {
        String nick = Prefs.get(a, "nick", "");
        if (!Prefs.validNick(nick)) {
            U.toast(a, "Введіть нікнейм: 3–16 символів, літери, цифри або _");
            return;
        }
        final String host = srv.optString("host");
        final int port = srv.optInt("port", 19132);
        if (host.isEmpty()) { U.toast(a, "Адресу сервера не задано (Налаштування)"); return; }
        U.toast(a, "Перевірка сервера…");
        Remote.EX.execute(() -> {
            final Pinger.R r = Pinger.ping(host, port);
            Remote.H.post(() -> {
                if (a.isFinishing()) return;
                if (r.online) { step2(a, cfg, host, port); return; }
                new AlertDialog.Builder(a).setTitle("Сервер недоступний")
                        .setMessage(host + ":" + port + " не відповідає. Якщо це Aternos — запустіть сервер на aternos.org і зачекайте, поки він увімкнеться.")
                        .setPositiveButton("Все одно запустити", (d, w) -> step2(a, cfg, host, port))
                        .setNegativeButton("Скасувати", null).show();
            });
        });
    }

    static void step2(final Activity a, final JSONObject cfg, final String host, final int port) {
        if (!Mc.installed(a)) {
            new AlertDialog.Builder(a).setTitle("Minecraft не знайдено")
                    .setMessage("Встановіть Minecraft Bedrock Edition з офіційного магазину.")
                    .setPositiveButton("Відкрити магазин", (d, w) -> Mc.store(a))
                    .setNegativeButton("Скасувати", null).show();
            return;
        }
        List<JSONObject> miss = Mc.missing(a, cfg);
        if (miss.isEmpty()) { Mc.connect(a, host, port); return; }
        StringBuilder sb = new StringBuilder("Відсутні обов'язкові файли:\n");
        for (JSONObject f : miss) sb.append("• ").append(f.optString("name")).append("\n");
        new AlertDialog.Builder(a).setTitle("Потрібні доповнення").setMessage(sb.toString())
                .setPositiveButton("Завантажити", (d, w) -> a.startActivity(new Intent(a, DownloadsActivity.class)))
                .setNegativeButton("Все одно грати", (d, w) -> Mc.connect(a, host, port)).show();
    }
}
