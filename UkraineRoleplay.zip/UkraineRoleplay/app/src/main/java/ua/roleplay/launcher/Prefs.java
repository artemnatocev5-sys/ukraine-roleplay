package ua.roleplay.launcher;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("ur_prefs", Context.MODE_PRIVATE);
    }
    public static String get(Context c, String k, String d) { return sp(c).getString(k, d); }
    public static void set(Context c, String k, String v) { sp(c).edit().putString(k, v).apply(); }
    public static void remove(Context c, String k) { sp(c).edit().remove(k).apply(); }
    public static boolean validNick(String n) {
        return n != null && n.matches("[\\p{L}0-9_ ]{3,16}");
    }
}
