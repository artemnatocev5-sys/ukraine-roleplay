package ua.roleplay.launcher;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import java.io.File;

public class SettingsActivity extends BaseActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setup("НАЛАШТУВАННЯ");

        U.add(content, U.header(this, "Нікнейм"), 0);
        final EditText nick = U.edit(this, "Enter Username", Prefs.get(this, "nick", ""));
        U.add(content, nick, 0);
        TextView saveNick = U.btn(this, "Зберегти нікнейм", 15);
        saveNick.setOnClickListener(v -> {
            String n = nick.getText().toString().trim();
            if (!Prefs.validNick(n)) { U.toast(this, "3–16 символів: літери, цифри, _ або пробіл"); return; }
            Prefs.set(this, "nick", n);
            U.toast(this, "Збережено");
        });
        U.add(content, saveNick, 8);
        U.add(content, U.text(this, "Нікнейм зберігається в лаунчері. Ім'я в самій грі Minecraft Bedrock задає акаунт Xbox.", 12), 6);

        U.add(content, U.header(this, "Сервер"), 0);
        final EditText host = U.edit(this, "IP / домен (порожньо = з launcher.json)", Prefs.get(this, "host", ""));
        final EditText port = U.edit(this, "Порт (порожньо = з launcher.json)", Prefs.get(this, "port", ""));
        final EditText remote = U.edit(this, "URL launcher.json (https://…)", Prefs.get(this, "remote_url", Config.REMOTE_URL));
        U.add(content, host, 0);
        U.add(content, port, 8);
        U.add(content, remote, 8);
        TextView saveSrv = U.btn(this, "Зберегти адресу сервера", 15);
        saveSrv.setOnClickListener(v -> {
            String r = remote.getText().toString().trim();
            if (!r.isEmpty() && !r.startsWith("https://")) { U.toast(this, "Потрібне HTTPS-посилання"); return; }
            String pt = port.getText().toString().trim();
            if (!pt.isEmpty() && !pt.matches("\\d{1,5}")) { U.toast(this, "Некоректний порт"); return; }
            Prefs.set(this, "host", host.getText().toString().trim());
            Prefs.set(this, "port", pt);
            Prefs.set(this, "remote_url", r);
            U.toast(this, "Збережено");
        });
        U.add(content, saveSrv, 8);
        TextView reset = U.btn(this, "Скинути до типових", 15);
        reset.setOnClickListener(v -> {
            Prefs.remove(this, "host"); Prefs.remove(this, "port"); Prefs.remove(this, "remote_url");
            host.setText(""); port.setText(""); remote.setText(Config.REMOTE_URL);
            U.toast(this, "Скинуто");
        });
        U.add(content, reset, 8);

        U.add(content, U.header(this, "Лаунчер"), 0);
        TextView files = U.btn(this, "Керування завантаженими файлами", 15);
        files.setOnClickListener(v -> startActivity(new Intent(this, DownloadsActivity.class)));
        U.add(content, files, 0);
        TextView cache = U.btn(this, "Очистити кеш", 15);
        cache.setOnClickListener(v -> {
            new File(getFilesDir(), "launcher.json").delete();
            File[] fs = Downloader.dir(this).listFiles();
            if (fs != null) for (File f : fs) if (f.getName().endsWith(".part")) f.delete();
            File[] cs = getCacheDir().listFiles();
            if (cs != null) for (File f : cs) f.delete();
            U.toast(this, "Кеш очищено");
        });
        U.add(content, cache, 8);
        TextView upd = U.btn(this, "Перевірити оновлення", 15);
        upd.setOnClickListener(v -> Updater.check(this, true));
        U.add(content, upd, 8);
        TextView priv = U.btn(this, "Політика конфіденційності", 15);
        priv.setOnClickListener(v -> Remote.load(this, j -> U.open(this, Remote.link(j, "privacy"))));
        U.add(content, priv, 8);
        U.add(content, U.text(this, "Мова: українська", 14), 12);
        U.add(content, U.text(this, "UKRAINE ROLEPLAY Launcher v" + Config.VERSION_NAME + " (" + Config.VERSION_CODE + ")", 13), 8);
    }
}
