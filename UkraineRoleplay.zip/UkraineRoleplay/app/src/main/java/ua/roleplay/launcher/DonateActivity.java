package ua.roleplay.launcher;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public class DonateActivity extends BaseActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setup("ДОНАТ");
        Remote.load(this, cfg -> {
            content.removeAllViews();
            JSONArray a = cfg.optJSONArray("donate");
            if (a == null || a.length() == 0) {
                content.addView(U.text(this, "Інформація про привілеї та набори з'явиться незабаром.", 16));
                return;
            }
            U.add(content, U.text(this, "Оплата відкривається у браузері на сторінці платіжної системи.", 13), 0);
            for (int i = 0; i < a.length(); i++) {
                final JSONObject d = a.optJSONObject(i);
                if (d == null) continue;
                LinearLayout c = U.card(this);
                TextView t = U.text(this, d.optString("title") + "  —  " + d.optString("price"), 18);
                t.setTypeface(Typeface.DEFAULT_BOLD);
                c.addView(t);
                U.add(c, U.text(this, d.optString("desc"), 15), 6);
                TextView pay = U.btn(this, "Перейти до оплати", 16);
                pay.setOnClickListener(v -> {
                    String u = d.optString("url", "");
                    U.open(this, u.isEmpty() ? Remote.link(cfg, "donate_pay") : u);
                });
                U.add(c, pay, 10);
                U.add(content, c, 8);
            }
        });
    }
}
