package ua.roleplay.launcher;

import android.app.Activity;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;

public abstract class BaseActivity extends Activity {
    protected LinearLayout content;

    protected void setup(String title) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(U.BG);
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        int p = U.dp(this, 12);
        bar.setPadding(p, p, p, p);
        TextView back = U.btn(this, "←", 18);
        back.setOnClickListener(v -> finish());
        TextView t = U.text(this, title, 20);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(U.dp(this, 16), 0, 0, 0);
        bar.addView(back);
        bar.addView(t);
        ScrollView sv = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(p, 0, p, p * 2);
        sv.addView(content);
        root.addView(bar);
        root.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }
}
