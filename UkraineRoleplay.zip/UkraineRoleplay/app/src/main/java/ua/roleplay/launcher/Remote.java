package ua.roleplay.launcher;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Remote {
    public interface CB { void done(JSONObject j); }
    public static final ExecutorService EX = Executors.newCachedThreadPool();
    public static final Handler H = new Handler(Looper.getMainLooper());

    public static void load(Context c, final CB cb) {
        final Context a = c.getApplicationContext();
        EX.execute(() -> {
            JSONObject j = null;
            String url = Prefs.get(a, "remote_url", Config.REMOTE_URL);
            File cache = new File(a.getFilesDir(), "launcher.json");
            if (url != null && url.startsWith("https://")) {
                try {
                    String s = http(url);
                    j = new JSONObject(s);
                    FileOutputStream o = new FileOutputStream(cache);
                    o.write(s.getBytes("UTF-8"));
                    o.close();
                } catch (Exception e) { j = null; }
            }
            if (j == null && cache.exists()) {
                try { j = new JSONObject(read(new FileInputStream(cache))); } catch (Exception e) { }
            }
            if (j == null) {
                try { j = new JSONObject(read(a.getAssets().open("launcher.json"))); }
                catch (Exception e) { j = new JSONObject(); }
            }
            final JSONObject r = j;
            H.post(() -> cb.done(r));
        });
    }

    static String http(String url) throws IOException {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(8000);
        h.setReadTimeout(8000);
        if (h.getResponseCode() != 200) throw new IOException("HTTP " + h.getResponseCode());
        return read(h.getInputStream());
    }

    static String read(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) != -1) b.write(buf, 0, n);
        in.close();
        return b.toString("UTF-8");
    }

    /** Список серверів; перший сервер можна перевизначити в Налаштуваннях (host/port). */
    public static List<JSONObject> servers(Context c, JSONObject j) {
        List<JSONObject> l = new ArrayList<>();
        JSONArray a = j.optJSONArray("servers");
        if (a != null) for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null) l.add(o);
        }
        if (l.isEmpty()) l.add(new JSONObject());
        try {
            JSONObject f = new JSONObject(l.get(0).toString());
            String h = Prefs.get(c, "host", "");
            String p = Prefs.get(c, "port", "");
            if (!h.isEmpty()) f.put("host", h);
            if (!p.isEmpty()) {
                try { f.put("port", Integer.parseInt(p)); } catch (Exception e) { }
            }
            l.set(0, f);
        } catch (Exception e) { }
        return l;
    }

    public static String link(JSONObject cfg, String key) {
        JSONObject l = cfg.optJSONObject("links");
        return l == null ? "" : l.optString(key, "");
    }
}
