package ua.roleplay.launcher;

import android.content.Context;
import android.os.StatFs;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

public class Downloader {
    public interface L { void progress(long done, long total); void ok(File f); void fail(String m); }
    public static class Task { public volatile boolean cancel; }

    public static File dir(Context c) {
        File b = c.getExternalFilesDir(null);
        if (b == null) b = c.getFilesDir();
        File d = new File(b, "downloads");
        d.mkdirs();
        return d;
    }

    public static Task start(Context ctx, final String url, final String name, final String sha, final L l) {
        final Context c = ctx.getApplicationContext();
        final Task t = new Task();
        Remote.EX.execute(() -> {
            String err = null;
            final File out = new File(dir(c), name);
            File part = new File(dir(c), name + ".part");
            try {
                if (url == null || !url.startsWith("https://"))
                    throw new IOException("Дозволені лише HTTPS-посилання");
                long have = part.exists() ? part.length() : 0;
                HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
                h.setConnectTimeout(10000);
                h.setReadTimeout(15000);
                if (have > 0) h.setRequestProperty("Range", "bytes=" + have + "-");
                int code = h.getResponseCode();
                if (code == 416) { part.delete(); throw new IOException("Спробуйте ще раз"); }
                if (code != 200 && code != 206) throw new IOException("Сервер файлів відповів: " + code);
                boolean append = code == 206;
                if (!append) have = 0;
                long len = h.getContentLength();
                final long total = len > 0 ? len + have : -1;
                if (len > 0) {
                    StatFs fs = new StatFs(dir(c).getPath());
                    if (fs.getAvailableBytes() < len + (8L << 20))
                        throw new IOException("Недостатньо вільного місця на телефоні");
                }
                InputStream in = h.getInputStream();
                FileOutputStream o = new FileOutputStream(part, append);
                byte[] buf = new byte[16384];
                long done = have, last = 0;
                int n;
                try {
                    while ((n = in.read(buf)) != -1) {
                        if (t.cancel) throw new IOException("Скасовано");
                        o.write(buf, 0, n);
                        done += n;
                        long now = System.currentTimeMillis();
                        if (now - last > 250) {
                            last = now;
                            final long d2 = done;
                            Remote.H.post(() -> l.progress(d2, total));
                        }
                    }
                } finally { o.close(); in.close(); }
                if (total > 0 && done < total) throw new IOException("Завантаження перервано");
                if (sha != null && !sha.isEmpty() && !sha256(part).equalsIgnoreCase(sha)) {
                    part.delete();
                    throw new IOException("Контрольна сума не збігається — файл пошкоджено");
                }
                if (out.exists()) out.delete();
                if (!part.renameTo(out)) throw new IOException("Не вдалося зберегти файл");
            } catch (Exception e) {
                err = e.getMessage() != null ? e.getMessage() : "Помилка мережі";
            }
            final String fe = err;
            Remote.H.post(() -> { if (fe == null) l.ok(out); else l.fail(fe); });
        });
        return t;
    }

    public static String sha256(File f) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        InputStream in = new FileInputStream(f);
        byte[] b = new byte[16384];
        int n;
        while ((n = in.read(b)) != -1) md.update(b, 0, n);
        in.close();
        StringBuilder s = new StringBuilder();
        for (byte x : md.digest()) s.append(String.format("%02x", x));
        return s.toString();
    }
}
