package ua.roleplay.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;
import org.json.JSONObject;

public class MainActivity extends Activity {
    JSONObject cfg = new JSONObject(), srv = new JSONObject();
    EditText nick;
    TextView online;
    View dot;
    final Runnable poll = new Runnable() {
        public void run() { ping(); Remote.H.postDelayed(this, 20000); }
    };

    FrameLayout.LayoutParams fl(int w, int h, int g, int l, int t, int r, int b) {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w, h, g);
        p.setMargins(U.dp(this, l), U.dp(this, t), U.dp(this, r), U.dp(this, b));
        return p;
    }

    TextView nav(String t, View.OnClickListener l) {
        TextView v = U.btn(this, t, 14);
        v.setOnClickListener(l);
        return v;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        FrameLayout root = new FrameLayout(this);
        final int W = FrameLayout.LayoutParams.WRAP_CONTENT;

        // Фон: покладіть свій арт як res/drawable-nodpi/bg_art.jpg (або .png)
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        int art = U.res(this, "bg_art", "drawable");
        bg.setImageResource(art != 0 ? art : R.drawable.bg_main);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        // Верхнє ліве меню
        LinearLayout tl = new LinearLayout(this);
        tl.addView(nav("СЕРВЕРИ", v -> startActivity(new Intent(this, ServersActivity.class))), lpR());
        tl.addView(nav("ФОРУМ", v -> forumMenu()), lpR());
        tl.addView(nav("ДОНАТ", v -> startActivity(new Intent(this, DonateActivity.class))), lpR());
        root.addView(tl, fl(W, W, Gravity.TOP | Gravity.START, 16, 12, 0, 0));

        // Верхнє праве меню: соцмережі (замініть гліфи іконками за потреби)
        LinearLayout tr = new LinearLayout(this);
        TextView tg = U.sq(this, "✈", 0xFF1E88E5);
        TextView yt = U.sq(this, "▶", 0xFFC62828);
        TextView dc = U.sq(this, "D", 0xFF5865F2);
        tg.setOnClickListener(v -> U.open(this, Remote.link(cfg, "telegram")));
        yt.setOnClickListener(v -> U.open(this, Remote.link(cfg, "youtube")));
        dc.setOnClickListener(v -> U.open(this, Remote.link(cfg, "discord")));
        for (TextView s : new TextView[]{tg, yt, dc}) {
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(U.dp(this, 48), U.dp(this, 48));
            p.leftMargin = U.dp(this, 8);
            tr.addView(s, p);
        }
        root.addView(tr, fl(W, W, Gravity.TOP | Gravity.END, 0, 12, 16, 0));

        // Логотип: покладіть res/drawable-nodpi/logo.png, щоб замінити текстовий
        int logoRes = U.res(this, "logo", "drawable");
        if (logoRes != 0) {
            ImageView logo = new ImageView(this);
            logo.setImageResource(logoRes);
            logo.setAdjustViewBounds(true);
            root.addView(logo, fl(U.dp(this, 360), W, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 70, 0, 0));
        } else {
            LinearLayout lg = new LinearLayout(this);
            lg.setOrientation(LinearLayout.VERTICAL);
            lg.setGravity(Gravity.CENTER_HORIZONTAL);
            SpannableString s = new SpannableString("UKRAINE");
            s.setSpan(new ForegroundColorSpan(U.BLUE), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            TextView t1 = U.text(this, "", 48);
            t1.setText(s);
            t1.setTypeface(Typeface.DEFAULT_BOLD);
            t1.setShadowLayer(8, 0, 4, Color.BLACK);
            LinearLayout row = new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            View l1 = new View(this); l1.setBackgroundColor(U.BLUE);
            View l2 = new View(this); l2.setBackgroundColor(U.YELLOW);
            TextView t2 = U.text(this, "ROLEPLAY", 22);
            t2.setTypeface(Typeface.DEFAULT_BOLD);
            t2.setPadding(U.dp(this, 10), 0, U.dp(this, 10), 0);
            row.addView(l1, new LinearLayout.LayoutParams(U.dp(this, 50), U.dp(this, 4)));
            row.addView(t2);
            row.addView(l2, new LinearLayout.LayoutParams(U.dp(this, 50), U.dp(this, 4)));
            lg.addView(t1);
            lg.addView(row);
            root.addView(lg, fl(W, W, Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 80, 0, 0));
        }

        // Статус сервера (низ-ліво)
        LinearLayout st = new LinearLayout(this);
        st.setGravity(Gravity.CENTER_VERTICAL);
        st.setBackground(U.box(this, U.PANEL, U.BORDER, 8));
        int p = U.dp(this, 12);
        st.setPadding(p, p, p * 2, p);
        dot = new View(this);
        dot.setBackground(U.oval(0xFF888888));
        online = U.text(this, "Перевірка…", 14);
        online.setPadding(U.dp(this, 10), 0, 0, 0);
        st.addView(dot, new LinearLayout.LayoutParams(U.dp(this, 14), U.dp(this, 14)));
        st.addView(online);
        root.addView(st, fl(W, W, Gravity.BOTTOM | Gravity.START, 16, 0, 0, 16));

        // Нікнейм + налаштування + PLAY (низ-право)
        LinearLayout br = new LinearLayout(this);
        br.setOrientation(LinearLayout.VERTICAL);
        nick = U.edit(this, "Enter Username", Prefs.get(this, "nick", ""));
        nick.setTextSize(18);
        nick.setTypeface(Typeface.MONOSPACE);
        nick.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16)});
        br.addView(nick, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout row2 = new LinearLayout(this);
        TextView gear = U.sq(this, "⚙", U.PANEL);
        gear.setTextSize(26);
        gear.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        TextView play = U.btn(this, "⚔  Play", 24);
        play.setOnClickListener(v -> {
            Prefs.set(this, "nick", nick.getText().toString().trim());
            Flow.play(this, cfg, srv);
        });
        LinearLayout.LayoutParams g = new LinearLayout.LayoutParams(U.dp(this, 60), U.dp(this, 60));
        g.rightMargin = U.dp(this, 8);
        row2.addView(gear, g);
        row2.addView(play, new LinearLayout.LayoutParams(0, U.dp(this, 60), 1f));
        LinearLayout.LayoutParams r2 = new LinearLayout.LayoutParams(-1, -2);
        r2.topMargin = U.dp(this, 8);
        br.addView(row2, r2);
        root.addView(br, fl(U.dp(this, 260), W, Gravity.BOTTOM | Gravity.END, 0, 0, 16, 16));

        setContentView(root);
        Updater.check(this, false);
    }

    LinearLayout.LayoutParams lpR() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.rightMargin = U.dp(this, 8);
        return p;
    }

    void forumMenu() {
        final String[] items = {"Відкрити форум", "Новини", "Правила", "Про сервер", "Підтримка"};
        new AlertDialog.Builder(this).setTitle("ФОРУМ").setItems(items, (d, i) -> {
            if (i == 1) startActivity(new Intent(this, NewsActivity.class));
            else U.open(this, Remote.link(cfg, new String[]{"forum", "", "rules", "about", "support"}[i]));
        }).show();
    }

    void ping() {
        final String host = srv.optString("host");
        if (host.isEmpty()) return;
        final int port = srv.optInt("port", 19132);
        Remote.EX.execute(() -> {
            final Pinger.R r = Pinger.ping(host, port);
            Remote.H.post(() -> {
                if (isFinishing()) return;
                dot.setBackground(U.oval(r.online ? 0xFF22DD44 : 0xFFDD3333));
                online.setText(r.online ? "Online: " + r.players + " players" : "Offline");
            });
        });
    }

    @Override protected void onResume() {
        super.onResume();
        Remote.load(this, j -> {
            cfg = j;
            srv = Remote.servers(this, j).get(0);
            Remote.H.removeCallbacks(poll);
            Remote.H.post(poll);
        });
    }

    @Override protected void onPause() {
        super.onPause();
        Remote.H.removeCallbacks(poll);
        String n = nick.getText().toString().trim();
        if (Prefs.validNick(n)) Prefs.set(this, "nick", n);
    }
}
