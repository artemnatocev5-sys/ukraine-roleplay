package ua.roleplay.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import org.json.JSONObject;
import java.io.File;

public class Updater {
    public static void check(final Activity a, final boolean manual) {
        Remote.load(a, cfg -> {
            JSONObject v = cfg.optJSONObject("latest_version");
            if (v == null || v.optInt("code", 0) <= Config.VERSION_CODE) {
                if (manual) U.toast(a, "У вас остання версія");
                return;
            }
            if (a.isFinishing()) return;
            new AlertDialog.Builder(a).setTitle("Доступна версія " + v.optString("name"))
                    .setMessage(v.optString("changes", ""))
                    .setPositiveButton("Завантажити", (d, w) -> download(a, v))
                    .setNegativeButton("Пізніше", null).show();
        });
    }

    static void download(final Activity a, JSONObject v) {
        final String sha = v.optString("sha256");
        if (sha.isEmpty()) { U.toast(a, "Оновлення без контрольної суми не встановлюється"); return; }
        final Downloader.Task[] t = new Downloader.Task[1];
        final AlertDialog dlg = new AlertDialog.Builder(a).setTitle("Завантаження оновлення")
                .setMessage("0%").setCancelable(false).create();
        dlg.setButton(DialogInterface.BUTTON_NEGATIVE, "Скасувати", (d, w) -> { if (t[0] != null) t[0].cancel = true; });
        dlg.show();
        t[0] = Downloader.start(a, v.optString("apk_url"), "update.apk", sha, new Downloader.L() {
            public void progress(long done, long total) {
                dlg.setMessage(total > 0 ? (done * 100 / total) + "%" : (done / 1024) + " КБ");
            }
            public void ok(File f) { dlg.dismiss(); install(a, f); }
            public void fail(String m) { dlg.dismiss(); U.toast(a, "Оновлення: " + m); }
        });
    }

    static void install(Activity a, File f) {
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            U.toast(a, "Дозвольте встановлення з цього джерела і повторіть оновлення");
            a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + a.getPackageName())));
            return;
        }
        Uri u = FileProvider.getUriForFile(a, a.getPackageName() + ".fp", f);
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setDataAndType(u, "application/vnd.android.package-archive");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        a.startActivity(i);
    }
}
