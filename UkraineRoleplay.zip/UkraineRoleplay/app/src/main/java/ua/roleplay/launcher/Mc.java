package ua.roleplay.launcher;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Взаємодія з Minecraft Bedrock через офіційні механізми Android (intent / minecraft:// URI). */
public class Mc {
    public static boolean installed(Context c) {
        try { c.getPackageManager().getPackageInfo(Config.MC_PKG, 0); return true; }
        catch (Exception e) { return false; }
    }

    public static String version(Context c) {
        try { return c.getPackageManager().getPackageInfo(Config.MC_PKG, 0).versionName; }
        catch (Exception e) { return ""; }
    }

    public static void store(Context c) {
        try { c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + Config.MC_PKG))); }
        catch (Exception e) { U.open(c, "https://play.google.com/store/apps/details?id=" + Config.MC_PKG); }
    }

    /** Відкриває Minecraft і намагається одразу підключитись до сервера. */
    public static void connect(Context c, String host, int port) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("minecraft://connect?serverUrl=" + Uri.encode(host) + "&serverPort=" + port));
            i.setPackage(Config.MC_PKG);
            c.startActivity(i);
        } catch (Exception e) {
            Intent i = c.getPackageManager().getLaunchIntentForPackage(Config.MC_PKG);
            if (i != null) {
                c.startActivity(i);
                U.toast(c, "Додайте сервер вручну: " + host + ":" + port);
            } else U.toast(c, "Не вдалося відкрити Minecraft");
        }
    }

    public static void importFile(Context c, File f) {
        try {
            Uri u = FileProvider.getUriForFile(c, c.getPackageName() + ".fp", f);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, "application/octet-stream");
            i.setPackage(Config.MC_PKG);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            c.startActivity(i);
        } catch (Exception e) {
            U.toast(c, "Minecraft не зміг відкрити файл. Перевірте, що гра встановлена.");
        }
    }

    public static void importHelp(Context c) {
        new AlertDialog.Builder(c).setTitle("Імпорт у Minecraft")
                .setMessage("1. Minecraft відкриє файл і почне імпорт.\n2. Дочекайтесь повідомлення про успішний імпорт.\n"
                        + "3. Для текстур: Налаштування → Глобальні ресурси → Активувати.\n"
                        + "4. Якщо нічого не сталося — відкрийте файл через «Файли» і виберіть Minecraft.")
                .setPositiveButton("OK", null).show();
    }

    public static String fileName(JSONObject f) {
        String u = f.optString("url");
        int q = u.indexOf('?');
        String p = q > 0 ? u.substring(0, q) : u;
        int d = p.lastIndexOf('.');
        String ext = d > p.lastIndexOf('/') ? p.substring(d) : "";
        return f.optString("id").replaceAll("[^A-Za-z0-9_-]", "_") + ext;
    }

    public static boolean installedFile(Context c, JSONObject f) {
        File file = new File(Downloader.dir(c), fileName(f));
        return file.exists() && f.optString("version").equals(Prefs.get(c, "dl_" + f.optString("id"), ""));
    }

    static int cmp(String a, String b) {
        String[] x = a.split("[^0-9]+"), y = b.split("[^0-9]+");
        for (int i = 0; i < Math.max(x.length, y.length); i++) {
            int p = 0, q = 0;
            try { p = i < x.length ? Integer.parseInt(x[i]) : 0; } catch (Exception e) { }
            try { q = i < y.length ? Integer.parseInt(y[i]) : 0; } catch (Exception e) { }
            if (p != q) return p < q ? -1 : 1;
        }
        return 0;
    }

    /** true, якщо версія Minecraft не нижча за "min_mc" файлу (або вимога не задана). */
    public static boolean compat(Context c, JSONObject f) {
        String min = f.optString("min_mc", "");
        String v = version(c);
        return min.isEmpty() || v.isEmpty() || cmp(v, min) >= 0;
    }

    /** Обов'язкові файли ("required": true), яких ще немає. Файли з "pushed_by_server": true пропускаються. */
    public static List<JSONObject> missing(Context c, JSONObject cfg) {
        List<JSONObject> m = new ArrayList<>();
        JSONArray a = cfg.optJSONArray("files");
        if (a == null) return m;
        for (int i = 0; i < a.length(); i++) {
            JSONObject f = a.optJSONObject(i);
            if (f == null || !f.optBoolean("required") || f.optBoolean("pushed_by_server")) continue;
            if (!installedFile(c, f)) m.add(f);
        }
        return m;
    }
}
