package ua.roleplay.launcher;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;

/** Справжній Bedrock (RakNet) unconnected ping по UDP. */
public class Pinger {
    public static class R {
        public boolean online;
        public int players, max;
        public String motd = "", version = "";
    }

    static final byte[] MAGIC = {0, (byte) 0xff, (byte) 0xff, 0, (byte) 0xfe, (byte) 0xfe, (byte) 0xfe, (byte) 0xfe,
            (byte) 0xfd, (byte) 0xfd, (byte) 0xfd, (byte) 0xfd, 0x12, 0x34, 0x56, 0x78};

    public static R ping(String host, int port) {
        R r = new R();
        DatagramSocket s = null;
        try {
            s = new DatagramSocket();
            s.setSoTimeout(3000);
            ByteBuffer b = ByteBuffer.allocate(33);
            b.put((byte) 0x01);
            b.putLong(System.currentTimeMillis());
            b.put(MAGIC);
            b.putLong(0x1234L);
            byte[] d = b.array();
            s.send(new DatagramPacket(d, d.length, InetAddress.getByName(host), port));
            byte[] buf = new byte[2048];
            DatagramPacket p = new DatagramPacket(buf, buf.length);
            s.receive(p);
            if (buf[0] != 0x1c) return r;
            int len = ((buf[33] & 0xff) << 8) | (buf[34] & 0xff);
            String[] f = new String(buf, 35, len, "UTF-8").split(";");
            r.online = true;
            if (f.length > 1) r.motd = f[1];
            if (f.length > 3) r.version = f[3];
            if (f.length > 4) r.players = Integer.parseInt(f[4]);
            if (f.length > 5) r.max = Integer.parseInt(f[5]);
        } catch (Exception e) {
            // немає відповіді = офлайн (або помилка розбору після успішної відповіді)
        } finally {
            if (s != null) s.close();
        }
        return r;
    }
}
