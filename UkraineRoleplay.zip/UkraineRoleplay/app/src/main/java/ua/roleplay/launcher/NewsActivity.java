package ua.roleplay.launcher;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public class NewsActivity extends BaseActivity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setup("НОВИНИ");
        Remote.load(this, cfg -> {
            content.removeAllViews();
            JSONArray a = cfg.optJSONArray("news");
            if (a == null || a.length() == 0) {
                content.addView(U.text(this, "Новин поки немає.", 16));
                return;
            }
            for (int i = 0; i < a.length(); i++) {
                JSONObject n = a.optJSONObject(i);
                if (n == null) continue;
                LinearLayout c = U.card(this);
                TextView t = U.text(this, n.optString("title"), 18);
                t.setTypeface(Typeface.DEFAULT_BOLD);
                c.addView(t);
                TextView d = U.text(this, n.optString("date"), 12);
                d.setTextColor(0xFF9AA0C0);
                U.add(c, d, 2);
                U.add(c, U.text(this, n.optString("text"), 15), 6);
                U.add(content, c, 8);
            }
        });
    }
}
