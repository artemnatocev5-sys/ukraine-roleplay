package ua.roleplay.launcher;

public class Config {
    public static final int VERSION_CODE = 1;          // має збігатися з versionCode у app/build.gradle
    public static final String VERSION_NAME = "1.0.0";
    // HTTPS-адреса вашого launcher.json. Порожньо = використовується вбудований файл.
    public static final String REMOTE_URL = "";
    public static final String MC_PKG = "com.mojang.minecraftpe";
}
