package ua.roleplay.launcher;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class U {
    public static final int PANEL = 0xE61B2040, BORDER = 0xFF3B4170, BG = 0xFF0E1130,
            BLUE = 0xFF2A7DE1, YELLOW = 0xFFFFD700;

    public static int dp(Context c, int v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    public static GradientDrawable box(Context c, int fill, int stroke, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(dp(c, 2), stroke);
        g.setCornerRadius(dp(c, r));
        return g;
    }

    public static GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    public static TextView btn(Context c, String t, int sp) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextColor(Color.WHITE);
        v.setTextSize(sp);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setBackground(box(c, PANEL, BORDER, 8));
        int p = dp(c, 10);
        v.setPadding(p * 2, p, p * 2, p);
        v.setClickable(true);
        return v;
    }

    public static TextView sq(Context c, String glyph, int color) {
        TextView v = btn(c, glyph, 22);
        v.setBackground(box(c, color, BORDER, 8));
        v.setPadding(0, 0, 0, 0);
        return v;
    }

    public static TextView text(Context c, String t, int sp) {
        TextView v = new TextView(c);
        v.setText(t);
        v.setTextColor(Color.WHITE);
        v.setTextSize(sp);
        return v;
    }

    public static TextView header(Context c, String t) {
        TextView v = text(c, t, 18);
        v.setTextColor(YELLOW);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(0, dp(c, 16), 0, dp(c, 4));
        return v;
    }

    public static EditText edit(Context c, String hint, String value) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(0xFF9AA0C0);
        e.setSingleLine(true);
        e.setBackground(box(c, PANEL, BORDER, 8));
        int p = dp(c, 10);
        e.setPadding(p, p, p, p);
        return e;
    }

    public static void add(LinearLayout parent, View v, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(parent.getContext(), topDp);
        parent.addView(v, lp);
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(box(c, PANEL, BORDER, 10));
        int p = dp(c, 12);
        l.setPadding(p, p, p, p);
        return l;
    }

    public static void toast(Context c, String m) { Toast.makeText(c, m, Toast.LENGTH_LONG).show(); }

    public static int res(Context c, String name, String type) {
        return c.getResources().getIdentifier(name, type, c.getPackageName());
    }

    public static void open(Context c, String url) {
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) {
            toast(c, "Посилання ще не додано");
            return;
        }
        try { c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { toast(c, "Не вдалося відкрити посилання"); }
    }

    public static void loadImage(final ImageView iv, final String url) {
        if (url == null || !url.startsWith("https://")) return;
        Remote.EX.execute(() -> {
            try {
                HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
                h.setConnectTimeout(6000);
                h.setReadTimeout(6000);
                InputStream in = h.getInputStream();
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) != -1) b.write(buf, 0, n);
                byte[] d = b.toByteArray();
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(d, 0, d.length, o);
                o.inSampleSize = Math.max(1, Math.min(o.outWidth, o.outHeight) / 160);
                o.inJustDecodeBounds = false;
                final Bitmap bm = BitmapFactory.decodeByteArray(d, 0, d.length, o);
                Remote.H.post(() -> iv.setImageBitmap(bm));
            } catch (Exception e) { }
        });
    }
}
