# UKRAINE ROLEPLAY Launcher (Android, Java)

## Збірка APK
1. Android Studio (Koala або новіша) → File → Open → папка проєкту. Дочекайтесь Gradle Sync.
2. Build → Build App Bundle(s) / APK(s) → Build APK(s).
   APK: `app/build/outputs/apk/debug/app-debug.apk`. Для релізу — Build → Generate Signed Bundle / APK.
3. Скопіюйте APK на телефон і встановіть (дозвольте встановлення з невідомих джерел).

## Дизайн
- Фон: покладіть чистий арт (без кнопок) у `app/src/main/res/drawable-nodpi/bg_art.jpg` (або .png).
- Логотип: `app/src/main/res/drawable-nodpi/logo.png` (прозорий PNG). Без нього малюється текстовий логотип.
- Іконка застосунку: `res/drawable/ic_launcher.xml` (тимчасова синьо-жовта) — замініть на свою.

## Налаштування сервера
Адреса за замовчуванням — у `app/src/main/assets/launcher.json` (`servers[0].host/port`).
Без перевипуску: Налаштування → Сервер (host/port) або віддалений `launcher.json`:
вкажіть його HTTPS-URL в `Config.REMOTE_URL` (або в Налаштуваннях). Лаунчер кешує його.
Порт Aternos Bedrock дивіться в панелі Aternos (за замовчуванням 19132).

## Формат launcher.json
- `servers[]`: name, host, port, version, description.
- `links`: telegram, discord, youtube, forum, rules, about, support, donate_pay, privacy.
- `news[]`: title, date, text.
- `donate[]`: title, price, desc, url.
- `latest_version`: code, name, changes, apk_url, sha256.
- `files[]`: id, category (textures|models|cars|items|characters|addons|maps), name, desc, version,
  size, date, image, url (HTTPS), sha256, min_mc (необов'язково), required (true/false),
  pushed_by_server (true — сервер сам надсилає пак, лаунчер не вимагає імпорту).

## Додавання файлу
Завантажте .mcpack/.mcaddon/.mcworld/.zip на HTTPS-хостинг, порахуйте SHA-256
(`sha256sum file.mcpack`) і додайте запис у `files[]`. Лаунчер без перевипуску покаже його.

## Оновлення лаунчера
1. Збільшіть `versionCode`/`versionName` у `app/build.gradle` і `VERSION_CODE`/`VERSION_NAME` у `Config.java`.
2. Зберіть підписаний APK, завантажте на HTTPS, порахуйте SHA-256.
3. У `launcher.json` задайте `latest_version` (code більше за встановлений). APK без sha256 лаунчер не встановлює.

## Обмеження Android / Minecraft Bedrock
- Підключення: `minecraft://connect?serverUrl=…&serverPort=…`; якщо Minecraft не підтримує — відкривається гра і показується адреса.
- Нікнейм у грі задає Xbox-акаунт; лаунчер його лише зберігає.
- Імпорт: лише через відкриття файлу в Minecraft; чи завершився імпорт — лаунчер дізнатися не може.
- Aternos-сервер вимкнений, поки його не запустять на aternos.org, тому статус буде Offline.
- Мова інтерфейсу: наразі тільки українська.
- Іконки Telegram/YouTube/Discord — текстові гліфи; замініть на свої графічні.
